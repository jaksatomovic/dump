# open-ipod
## An iPod, but better

A revitalization using an iPod Photo (4th gen) based off of the ESP-32 MCU, built on the shoulders of giants

The plan so far is to create an interface based on the [LittlevGL library](https://lvgl.io/) and a [2.4" 240x320 TFT display](https://www.crystalfontz.com/product/cfaf240320k1024trt-240x320-rgb-tft-lcd).

I hope to re-use the iPod's ClickWheel using the work of GigaHawk's [ClickWheel Firmware](https://github.com/Gigahawk/clickwheel_sample_firmware), and eventually interface with the existing hold button and headphone jack

I'm hoping to work directly in C/C++ through ESP-IDF, as Arduino and MicroPython are too abstracted, and, if I'm going to learn a programming language, why not go straight for the gold with C/C++?

Would like USB-C support (both charging and data), and would like to use a Li-Po for the battery

A2DP support for audio out would be nice, and I plan on supporting MP3 and FLAC, along with AAC and OGG

There will be [two SQLite3 databases](https://github.com/siara-cc/esp32-idf-sqlite3): one for settings, and one for the library of music (which will need to be updated with artist, album, track title, etc. on a host PC)

I will go with [LITTLEFS](https://github.com/joltwallet/esp_littlefs) for the filesystem as (to quote the LITTLEFS project) "SPIFFS is too slow and FAT is too fragile".

At this point, I have determined the following:

-   I will be using ESP-IDF
-   I will be coding in C/C++
-   The UI will be programmed using the LittlevGL library
-   This will be based off of the ESP-WROOM-32 module
-   My eventual goal is a working drop in iPod replacement PCB that can replace the internals of the iPod
    -   Flash storage with larger capacity
    -   Larger battery capacity for longer runtime
    -   Similar UI
    -   Working ClickWheel support out of the box
    -   Bluetooth A2DP support for headphones, car stereos, and speakers
    -   WiFi for transferring files to and from the device
    -   WiFi for Internet Radio (Spotify?)
    -   Support for MP3, FLAC, AAC, OGG (Lyrics? AlbumArt? Other Codecs?)
    -   USB-C support for charging and (eventually) data transfer
