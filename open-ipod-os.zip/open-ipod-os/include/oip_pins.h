#pragma once

// define the pins used
#define VS1053_RESET -1 // VS1053 reset pin (output)
#define VS1053_CS 11    // VS1053 chip select pin (output)
#define VS1053_DCS 13   // VS1053 Data/command select pin (output)
#define CARDCS 10       // Card chip select pin
#define VS1053_DREQ 12  // VS1053 Data request, ideally an Interrupt pin

// #define MOSI 35 // Data out
// #define SCLK 36 // Clock out
// #define MISO 37 // Data in

//------------------

// #define TFT_CS 6  // Chip select control pin
// #define TFT_DC 5  // Data Command control pin
// #define TFT_RST 9 // Set TFT_RST to -1 if TFT RESET is connected to

// // OPTION 2 lets you interface the display using ANY TWO or THREE PINS,
// // tradeoff being that performance is not as fast as hardware SPI above.
// #define TFT_MOSI 35 // Data out
// #define TFT_SCLK 36 // Clock out

//------------------

#define CLOCK_PIN 4 // SCL purple
#define DATA_PIN 3  // SDA grey