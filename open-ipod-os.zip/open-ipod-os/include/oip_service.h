#ifndef OIP_SERVICE_H
#define OIP_SERVICE_H

#include <oip_app.h>

class OipServiceTask : public OipApp {
public:
  OipServiceTask() : OipApp() {}
  virtual void setup() override;
  bool isRunning();
  virtual void stop() override;
  virtual ~OipServiceTask(){};

private:
  bool taskEnabled = false;
};
#endif