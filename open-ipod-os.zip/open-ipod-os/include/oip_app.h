#ifndef OIP_APP_H
#define OIP_APP_H

#include <oip_hal.h>

class OipApp {
public:
  virtual void setup() = 0;
  virtual void loop() = 0;
  virtual void stop() = 0;
};

#endif