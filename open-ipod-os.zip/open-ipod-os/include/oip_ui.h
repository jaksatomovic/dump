#ifndef OIP_UI_H
#define OIP_UI_H

int MenuOption = 0;

// must have variables for each menu item
// best to have these global so you can use them in processing functions
int MenuOption1 = 0, MenuOption2 = 0, MenuOption3 = 0, MenuOption4 = 0,
    MenuOption5 = 0;
int MenuOption6 = 0, MenuOption7 = 0, MenuOption8 = 0, MenuOption9 = 0;

int MusicOption1 = 0, MusicOption2 = 0, MusicOption3 = 0, MusicOption4 = 0,
    MusicOption5 = 0;
int MusicOption6 = 0, MusicOption7 = 0, MusicOption8 = 0, MusicOption9 = 0,
    MusicOption10 = 0, MusicOption11 = 0;

int OptionOption1 = 0, OptionOption2 = 0, OptionOption3 = 0, OptionOption4 = 0,
    OptionOption5 = 0;
int OptionOption6 = 0, OptionOption7 = 0, OptionOption8 = 0, OptionOption9 = 0;

// variables to store some of the options, you will probably want a var for each
// note the menu code ONLY supports floats
// if you want to edit an int in the menu, still pass in a float and set decimal
// readout to 0 the recast the float to an int upon menu comletion processing
float Temp1Adj = 0.2, Temp2Adj = -.3, AlarmVal = 1;

// encoder stuff
long Position = 0, oldPosition = 0;

// create some selectable menu sub-items, these are lists inside a menu item
const char *ReadoutItems[] = {"Absolute", "Deg F", "Deg C"};
const char *RefreshItems[] = {"Off",        "1 second",   "2 seconds",
                              "10 seconds", "30 seconds", "1 minute",
                              "5 minutes"};
const char *PrecisionItems[] = {"10", "0", "0.0", "0.00", "0.000"};
const char *TuneItems[] = {"Slope/Offset", "Simple",    "Linear",
                           "2nd order ",   "3rd order", "Log"};
const char *OffOnItems[] = {"Off", "On"};

const char *DataRateItems[] = {"300 baud", "1.2 kbd",  "2.4 kbd", "4.8 kbd",
                               "9.6 kbd",  "19.2 kbd", "56 kbd"};

// OK i'm going crazy with examples, but this will help show more processing
// when an int is needed but a float returned from the menu code
const char *C_NAMES[] = {
    "White",         "Black",          "Grey",          "Blue",
    "Red",           "Green",          "Cyan",          "Magenta",
    "Yellow",        "Teal",           "Orange",        "Pink",
    "Purple",        "Lt Grey",        "Lt Blue",       "Lt Red",
    "Lt Green",      "Lt Cyan",        "Lt Magenta",    "Lt Yellow",
    "Lt Teal",       "Lt Orange",      "Lt Pink",       "Lt Purple",
    "Medium Grey",   "Medium Blue",    "Medium Red",    "Medium Green",
    "Medium Cyan",   "Medium Magenta", "Medium Yellow", "Medium Teal",
    "Medium Orange", "Medium Pink",    "Medium Purple", "Dk Grey",
    "Dk Blue",       "Dk Red",         "Dk Green",      "Dk Cyan",
    "Dk Magenta",    "Dk Yellow",      "Dk Teal",       "Dk Orange",
    "Dk Pink",       "Dk Purple"};

const uint16_t C_VALUES[] = {
    0XFFFF, 0X0000, 0XC618, 0X001F, 0XF800, 0X07E0, 0X07FF, 0XF81F, // 7
    0XFFE0, 0X0438, 0XFD20, 0XF81F, 0X801F, 0XE71C, 0X73DF, 0XFBAE, // 15
    0X7FEE, 0X77BF, 0XFBB7, 0XF7EE, 0X77FE, 0XFDEE, 0XFBBA, 0XD3BF, // 23
    0X7BCF, 0X1016, 0XB000, 0X0584, 0X04B6, 0XB010, 0XAD80, 0X0594, // 31
    0XB340, 0XB00E, 0X8816, 0X4A49, 0X0812, 0X9000, 0X04A3, 0X0372, // 39
    0X900B, 0X94A0, 0X0452, 0X92E0, 0X9009, 0X8012                  // 45
};

const uint16_t MAIN_COLORS[] = {0xCF1D, 0x2337};
// set default colors
uint16_t MENU_TEXT = ST7789_BLACK;
uint16_t MENU_BACKGROUND = ST7789_WHITE;
uint16_t MENU_HIGHLIGHTTEXT = ST7789_WHITE;
uint16_t MENU_HIGHLIGHT = MAIN_COLORS[1];
uint16_t MENU_HIGHBORDER = MAIN_COLORS[1];
uint16_t MENU_SELECTTEXT = C_VALUES[0];
uint16_t MENU_SELECT = C_VALUES[4];
uint16_t MENU_SELECTBORDER = C_VALUES[37];
uint16_t MENU_DISABLE = ST7789_WHITE; // ST7789_GRAY;
uint16_t TITLE_TEXT = ST7789_BLACK;
uint16_t TITLE_BACK = MAIN_COLORS[0];

#endif