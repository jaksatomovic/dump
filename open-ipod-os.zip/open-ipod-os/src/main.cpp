#include "Adafruit_LC709203F.h"
#include "Adafruit_VS1053.h"
#include "clickwheel.h"
#include "logo.h"
#include "oip_gui.h"
#include "oip_pins.h"
#include "oip_ui.h"
#include <Arduino.h>
#include <SD.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include <TFT_eWidget.h>
#include <string>
#include <vector>

static const BaseType_t pro_cpu = 0;
static const BaseType_t app_cpu = 1;

void drawLogo();
bool nameCheck(char *name);
void loadTracks(File dir, int level);
const char *appendRootPath(char *name);
void clickwheelTask(void *pvParameters);
void musicPlayerTask(void *pvParameters);
void boot(void *pvParameters);
void tftInit();
void processSettingsMenu();
void processMusicPlayerScreen(bool isPlaying, std::string songTitle);
void wheelButtonPress(int WheelButton);
void clickWheelInit(void);
void startStopSong(void);
void playPauseSong(void);
void processMusicList();
void updateVolumeSlider(bool volumeUp);
void processMusicsMenu();
IRAM_ATTR void onClockEdge(void);
IRAM_ATTR void onClockEdgeF(void);
ICACHE_RAM_ATTR void onDataEdgeF(void);
ICACHE_RAM_ATTR void onDataEdge(void);
ICACHE_RAM_ATTR int setBit(int n, int k);
ICACHE_RAM_ATTR int clearBit(int n, int k);
ICACHE_RAM_ATTR void clickWheelEvents();
ICACHE_RAM_ATTR void wheelScroll(int Inc);
ICACHE_RAM_ATTR void processClickWheel(int button, int button_state,
                                       int position);

Adafruit_VS1053_FilePlayer musicPlayer =
    Adafruit_VS1053_FilePlayer(VS1053_CS, VS1053_DCS, VS1053_DREQ, CARDCS);

TFT_eSPI display = TFT_eSPI();
TFT_eSprite knob = TFT_eSprite(&display);

SliderWidget volumeSlider = SliderWidget(&display, &knob);
// Create a parameter set for the slider
slider_t param;

long lastVolumeUpdate;

Adafruit_LC709203F lc;

#define TRACKS_MAX 999
#define AUTO_PLAY_NEXT true
#define DATA_COLUMN 200

#define FONT_TITLE FreeSans9pt7b // font for all headings
#define FONT_ITEM FreeSans9pt7b  // font for all headings
#define FONT_SMALL FreeSans9pt7b // font for all headings

int currentTrack, totalTracks;
char trackListing[TRACKS_MAX][13] = {' '};
std::vector<std::string> cashedSongs;
std::vector<std::string> listedSongs;

enum mode { PLAYING, PAUSED, STOPPED } currentMode = STOPPED;

bool START_STOP_FLAG = false;
bool PLAY_PAUSE_FLAG = false;
bool NEXT_SONG_FLAG = false;
bool PREVIOUS_SONG_FLAG = false;
bool VOLUME_UP_FLAG = false;
bool VOLUME_DOWN_FLAG = false;

bool GO_BACK_FLAG = false;

bool SHUFFLE_MODE = false;

bool SCROLL_DOWN_FLAG = false;
bool SCROLL_UP_FLAG = false;

bool NOW_PLAYING_SCREEN = false;
bool PLAYED_BY_NAME = false;

static int iVol = 20;
static int speakerVolume = 20;

// set an inital flag that will be used to store what menu item the user
// exited on
int MainMenuOption = 1;
int MusicMenuOption = 4;

ItemMenu MainMenu(&display, &lc, &musicPlayer);
ItemMenu MusicMenu(&display, &lc, &musicPlayer);
ItemMenu MusicList(&display, &lc, &musicPlayer);

EditMenu SettingsMenu(&display, &lc, &musicPlayer);

void setup() {
  Serial.begin(9600);

  vTaskDelay(2000 / portTICK_PERIOD_MS);

  display.init();

  display.setRotation(3);

  drawLogo();

  // Slider slot parameters
  param.slotWidth = 0;    // Note: ends of slot will be rounded and anti-aliased
  param.slotLength = 265; // Length includes rounded ends
  param.slotColor = TFT_WHITE;   // Slot colour
  param.slotBgColor = TFT_WHITE; // Slot background colour for anti-aliasing
  param.orientation = H_SLIDER;  // sets it "true" for horizontal

  // Slider control knob parameters (smooth rounded rectangle)
  param.knobWidth = 15;       // Always along x axis
  param.knobHeight = 15;      // Always along y axis
  param.knobRadius = 0;       // Corner radius
  param.knobColor = TFT_BLUE; // Anti-aliased with slot backgound colour
  param.knobLineColor = TFT_BLUE;

  // Slider range and movement speed
  param.sliderLT = 0;   // Left side for horizontal, top for vertical slider
  param.sliderRB = 100; // Right side for horizontal, bottom for vertical slider
  param.startPosition = 10; // Start position for control knob
  param.sliderDelay = 0; // Microseconds per pixel movement delay (0 = no delay)

  volumeSlider.setSliderPosition(10);

  // if (!lc.begin()) {
  //   Serial.println(F("Couldnt find Adafruit LC709203F?\nMake sure a
  //   battery is "
  //                    "plugged in!"));
  //   while (1)
  //     delay(10);
  // }
  // Serial.println(F("Found LC709203F"));
  // Serial.print("Version: 0x");
  // Serial.println(lc.getICversion(), HEX);

  // lc.setThermistorB(3950);
  // Serial.print("Thermistor B = ");
  // Serial.println(lc.getThermistorB());

  // lc.setPackSize(LC709203F_APA_500MAH);

  // lc.setAlarmVoltage(3.8);

  if (!musicPlayer.begin()) { // initialise the music player
    Serial.println(
        F("Couldn't find VS1053, do you have the right pins defined?"));
    while (1)
      ;
  }
  Serial.println(F("VS1053 found"));
  if (!musicPlayer.useInterrupt(VS1053_FILEPLAYER_PIN_INT)) // DREQ int
    Serial.println(F("DREQ pin is not an interrupt pin"));

  musicPlayer.setVolume(10, 10);

  if (!SD.begin(CARDCS)) {
    Serial.println(F("SD failed, or not present"));
    while (1)
      ; // don't do anything more
  }

  // Load list of tracks
  totalTracks = 0;
  loadTracks(SD.open("/"), 0);
  currentTrack = 0;

  // Initiaise the Apple Click Wheel
  clickWheelInit();
  Serial.println("Click Wheel Init...");

  xTaskCreatePinnedToCore(boot, "bootTask", 4096, NULL, 1, NULL, app_cpu);
  xTaskCreatePinnedToCore(musicPlayerTask, "musicPlayerTask", 4096, NULL, 1,
                          NULL, app_cpu);
  // xTaskCreatePinnedToCore(tftTask, "tftTask", 4096, NULL, 1, NULL, app_cpu);

  // Delete "setup and loop" task
  vTaskDelete(NULL);
}

void drawLogo() {
  display.fillScreen(ST7789_BLACK);

  int x = display.width() / 2 - logoWidth / 2;
  int y = display.height() / 2 - logoHeight / 2;

  // Draw bitmap with top left corner at x,y with foreground only color
  // Bits set to 1 plot as the defined color, bits set to 0 are not plotted
  //              x  y  xbm   xbm width  xbm height  color
  display.drawXBitmap(x, y, logo, logoWidth, logoHeight, TFT_WHITE);
}

void loadTracks(File dir, int level) {
  while (true) {
    File entry = dir.openNextFile();
    if (!entry)
      return;
    if (entry.isDirectory()) {
      // Recursive call to scan next dir level
      loadTracks(entry, level + 1);
    } else {
      // Only add files in root dir
      if (level == 0) {
        // And only if they have good names
        if (nameCheck((char *)entry.name())) {
          std::string x = entry.name();
          cashedSongs.push_back(x.substr(0, 8));
          strncpy(trackListing[totalTracks], entry.name(), 12);
          Serial.print(totalTracks);
          Serial.print("=");
          Serial.println(trackListing[totalTracks]);
          totalTracks++;
        }
      }
    }
    entry.close();
    // Stop scanning if we hit max
    if (totalTracks >= TRACKS_MAX)
      return;
  }
}

bool nameCheck(char *name) {
  int len = strlen(name);
  // Check length
  if (len <= 4)
    return false;
  // Check extension
  char *ext = strrchr(name, '.');
  if (!(strcmp(ext, ".mp3") == 0 || strcmp(ext, ".ogg") == 0 ||
        strcmp(ext, ".MP3") == 0 || strcmp(ext, ".OGG") == 0))
    return false;
  // Check first character
  switch (name[0]) {
  case '_':
    return false;
  case '.':
    return false;
  }

  return true;
}

const char *appendRootPath(std::string name) {
  std::string str = "/";

  str += name;
  return str.c_str();
}

void boot(void *pvParameters) {
  (void)pvParameters;

  /*
   * MAIN MENU
   */

  MainMenu.init(MENU_TEXT, MENU_BACKGROUND, MENU_HIGHLIGHTTEXT, MENU_HIGHLIGHT,
                30, 6, "iPod", FONT_ITEM, FONT_TITLE);

  MenuOption1 = MainMenu.addNI("Music");
  MenuOption2 = MainMenu.addNI("Extras");
  MenuOption3 = MainMenu.addNI("Settings");
  MenuOption4 = MainMenu.addNI("Shuffle Songs");
  MenuOption5 = MainMenu.addNI("Backlight");
  MenuOption6 = MainMenu.addNI("Now Playing");

  MainMenu.disable(MenuOption6);

  MainMenu.setTitleColors(TITLE_TEXT, TITLE_BACK);
  MainMenu.setTitleBarSize(0, 0, 320, 40);
  MainMenu.setTitleTextMargins(140, 30);
  MainMenu.setIconMargins(0, 0);
  MainMenu.setMenuBarMargins(0, 320, 0, 0);
  MainMenu.setItemColors(MENU_DISABLE, MENU_HIGHBORDER);
  MainMenu.setItemTextMargins(10, 20, 0);

  /*
   * MUSIC MENU
   */

  MusicMenu.init(MENU_TEXT, MENU_BACKGROUND, MENU_HIGHLIGHTTEXT, MENU_HIGHLIGHT,
                 30, 6, "iPod", FONT_ITEM, FONT_TITLE);

  MusicOption1 = MusicMenu.addNI("Playists");
  MusicOption2 = MusicMenu.addNI("Artists");
  MusicOption3 = MusicMenu.addNI("Albums");
  MusicOption4 = MusicMenu.addNI("Songs");
  MusicOption5 = MusicMenu.addNI("Podcasts");
  MusicOption6 = MusicMenu.addNI("Genres");
  MusicOption7 = MusicMenu.addNI("Composers");
  MusicOption8 = MusicMenu.addNI("Audiobooks");

  MusicMenu.setTitleColors(TITLE_TEXT, TITLE_BACK);
  MusicMenu.setTitleBarSize(0, 0, 320, 40);
  MusicMenu.setTitleTextMargins(140, 30);
  MusicMenu.setIconMargins(0, 0);
  MusicMenu.setMenuBarMargins(0, 320, 0, 0);
  MusicMenu.setItemColors(MENU_DISABLE, MENU_HIGHBORDER);
  MusicMenu.setItemTextMargins(10, 20, 0);

  /*
   * MUSIC LIST (SONGS) MENU
   */

  MusicList.init(MENU_TEXT, MENU_BACKGROUND, MENU_HIGHLIGHTTEXT, MENU_HIGHLIGHT,
                 30, 6, "Songs", FONT_ITEM, FONT_TITLE);

  MusicList.setTitleColors(TITLE_TEXT, TITLE_BACK);
  MusicList.setTitleBarSize(0, 0, 320, 40);
  MusicList.setTitleTextMargins(140, 30);
  MusicList.setIconMargins(0, 0);
  MusicList.setMenuBarMargins(0, 320, 0, 0);
  MusicList.setItemColors(MENU_DISABLE, MENU_HIGHBORDER);
  MusicList.setItemTextMargins(10, 20, 0);

  /*
   * SETTINGS MENU
   */

  SettingsMenu.init(MENU_TEXT, MENU_BACKGROUND, MENU_HIGHLIGHTTEXT,
                    MENU_HIGHLIGHT, MENU_SELECTTEXT, MENU_SELECT, DATA_COLUMN,
                    30, 6, "Settings", FONT_ITEM,
                    FONT_TITLE); // ROW_HEIGHT, ROWS

  OptionOption1 = SettingsMenu.addNI("Colors", 1, 0,
                                     sizeof(OffOnItems) / sizeof(OffOnItems[0]),
                                     1, 0, OffOnItems);
  OptionOption2 =
      SettingsMenu.addNI("Temp Adj.", Temp2Adj, -1.0, 1.0, .05, 2, NULL);
  OptionOption3 = SettingsMenu.addNI(
      "Readout", 2, 0, sizeof(ReadoutItems) / sizeof(ReadoutItems[0]), 1, 0,
      ReadoutItems);
  OptionOption4 = SettingsMenu.addNI("Tune", 0, 0, 20, 1, 0, NULL);
  OptionOption5 = SettingsMenu.addNI("Alarm", AlarmVal, 0,
                                     sizeof(OffOnItems) / sizeof(OffOnItems[0]),
                                     1, 0, OffOnItems);
  OptionOption6 = SettingsMenu.addNI(
      "Precision", 0, 0, sizeof(PrecisionItems) / sizeof(PrecisionItems[0]), 1,
      0, PrecisionItems);
  OptionOption7 = SettingsMenu.addNI("Tune", 0, 0, 20, 1, 0, NULL);

  SettingsMenu.SetItemValue(OptionOption1, 0.12);
  SettingsMenu.SetItemValue(OptionOption3, 1);
  SettingsMenu.setTitleColors(TITLE_TEXT, TITLE_BACK);
  SettingsMenu.setTitleBarSize(0, 0, 320, 40);
  SettingsMenu.setTitleTextMargins(125, 30);
  SettingsMenu.setIconMargins(0, 0);
  SettingsMenu.setItemTextMargins(10, 20, 0);
  SettingsMenu.setItemColors(MENU_DISABLE, MENU_HIGHBORDER, MENU_SELECTBORDER);

  // blank out the screen
  display.fillScreen(MENU_BACKGROUND);

  // draw the main menu
  MainMenu.draw();

  MainMenuOption = MainMenu.selectRow();

  // Loop forever
  while (1) {

    // run the processing loop until user move selector to title bar (which
    // becomes exit, i.e. 0 return val) and selectes it note menu code can
    // return
    // - 1 for errors so run unitl non zero
    while (MainMenuOption != 0) {
      if (SCROLL_UP_FLAG && !NOW_PLAYING_SCREEN) {
        MainMenu.MoveDown();
        SCROLL_UP_FLAG = false;
      }
      if (SCROLL_DOWN_FLAG && !NOW_PLAYING_SCREEN) {
        MainMenu.MoveUp();
        SCROLL_DOWN_FLAG = false;
      }
      if (START_STOP_FLAG && !NOW_PLAYING_SCREEN) {
        START_STOP_FLAG = false;

        // get the row the selector is on
        MainMenuOption = MainMenu.selectRow();

        // here is where you process accordingly
        // remember on pressing button on title bar 0 is returned and will
        // exit the loop

        if (MainMenuOption == MenuOption1) {
          // item 3 was the Option menu
          processMusicsMenu();
          // when done processing that menu, return here
          // clear display and redraw this main menu
          display.fillScreen(MENU_BACKGROUND);
          MainMenu.draw();
        }

        if (MainMenuOption == MenuOption3) {
          // item 3 was the Option menu
          processSettingsMenu();
          // when done processing that menu, return here
          // clear display and redraw this main menu
          display.fillScreen(MENU_BACKGROUND);
          MainMenu.draw();
        }
        if (MainMenuOption == MenuOption4) {
          // item 3 was the Option menu
          processMusicPlayerScreen(false, "");
          // when done processing that menu, return here
          // clear display and redraw this main menu
          display.fillScreen(MENU_BACKGROUND);
          MainMenu.draw();
        }

        if (MainMenuOption == MenuOption6) {
          // item 3 was the Option menu
          processMusicPlayerScreen(true, "");
          // when done processing that menu, return here
          // clear display and redraw this main menu
          display.fillScreen(MENU_BACKGROUND);
          MainMenu.draw();
        }
      }
    }
  }
}

void clickWheelInit() {
  // Ipod Classic 4th generation click wheel, configure pins and input
  // interupts
  pinMode(CLOCK_PIN, INPUT_PULLUP);
  pinMode(DATA_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(GPIO_CLOCK_PIN), onClockEdge, RISING);
  attachInterrupt(digitalPinToInterrupt(GPIO_DATA_PIN), onDataEdge, CHANGE);
}

IRAM_ATTR void onDataEdge() { dataBit = (digitalRead(GPIO_DATA_PIN)); }

IRAM_ATTR void onClockEdge() {
  if (dataBit == 0) {
    recording = 1;
    oneCount = 0;
  } else {
    // 32 1's in a row means we're definitely not in the middle of a packet
    if (++oneCount >= BIT_COUNT) {
      recording = 0;
      bitIndex = 0;
    }
  }
  // in the middle of the packet
  if (recording == 1) {
    if (dataBit) {
      bits = setBit(bits, bitIndex);
    } else {
      bits = clearBit(bits, bitIndex);
    }
    // we've collected the whole packet
    if (++bitIndex == 32) {
      bitIndex = 0;
      // click_wheel_packets_received = true;
      clickWheelEvents(); // lets not call this inside the interuptloop
    }
  }
}

ICACHE_RAM_ATTR void clickWheelEvents() { // parse packet and broadcast data
  if ((bits & PACKET_START) != PACKET_START) {
    return;
  }
  for (size_t i = 0; i < BUFFER_SIZE; i++) {
    buffer[i] = -1;
  }

  for (size_t i = 0; i < sizeof(buttons); i++) {
    char buttonIndex = buttons[i];
    if ((bits >> buttonIndex) & 1 && !((lastBits >> buttonIndex) & 1)) {
      buffer[BUTTON_INDEX] = buttonIndex;
      buffer[BUTTON_STATE_INDEX] = 1;
    } else if (!((bits >> buttonIndex) & 1) && (lastBits >> buttonIndex) & 1) {
      buffer[BUTTON_INDEX] = buttonIndex;
      buffer[BUTTON_STATE_INDEX] = 0;
    }
  }
  uint8_t wheelPosition = (bits >> 16) & 0xFF;

  buffer[WHEEL_POSITION_INDEX] = wheelPosition;
  if (memcmp(prev_buffer, buffer, BUFFER_SIZE) == 0) {
    return;
  }

  lastBits = bits;

  processClickWheel((int)buffer[BUTTON_INDEX], (int)buffer[BUTTON_STATE_INDEX],
                    (int)buffer[WHEEL_POSITION_INDEX]);

  memcpy(prev_buffer, buffer, BUFFER_SIZE);
}

// Function to set the kth bit of n
ICACHE_RAM_ATTR int setBit(int n, int k) { return (n | (1 << (k - 1))); }

// Function to clear the kth bit of n
ICACHE_RAM_ATTR int clearBit(int n, int k) { return (n & (~(1 << (k - 1)))); }

ICACHE_RAM_ATTR void processClickWheel(int button, int button_state,
                                       int position) {

  if (button == WHEEL_TOUCH_BIT &&
      button_state == 0) { // Finger has left scroll wheel
    wheel_scroll_lift = true;
    ClickWheelScrollPrev[5] =
        0; // Reset to circular buffer of wheels scroll events to reset as
           // scroll directions as the finger has left the wheel
    ClickWheelScrollPrev[4] = 0;
    ClickWheelScrollPrev[3] = 0;
    ClickWheelScrollPrev[2] = 0;
    ClickWheelScrollPrev[1] = 0;
    ClickWheelScrollPrev[0] = 0;
  }

  if (button == WHEEL_TOUCH_BIT &&
      button_state == 1) { // Finger has Been presented to touch wheel
    wheel_scroll_lift = false;
    return;
  }

  if (button == 255 && button_state == 255) { // Finger is scrolling wheel
    if (ClickWheelClicked) {
      ClickWheelClicked =
          false; // ignore an initial touch on wheel just after a click
      return;
    }

    // Click wheel events run from 1-48 so i use this to managed the
    // transitions fro 48 to 0 or 0 to 48
    if (last_wheel_position > 45 && position < 5) {
      wheelScroll(-1);
      // VOLUME_DOWN_FLAG = true;
      SCROLL_DOWN_FLAG = true;
    } else if (last_wheel_position < 5 && position > 45) {
      wheelScroll(1);
      SCROLL_UP_FLAG = true;
      // VOLUME_UP_FLAG = true;
    } else if (last_wheel_position > position) {
      wheelScroll(-1);
      SCROLL_DOWN_FLAG = true;
    } else {
      wheelScroll(1);
      SCROLL_UP_FLAG = true;
    }
    last_wheel_position = position;
    InputReceived = true; // InputSleepCheck
    return;
  }

  if (button_state == 0 && button != 255) { // We have a button click event
    ClickWheelClicked = true;
    switch (button) {
    case CENTER_BUTTON_BIT:
      wheelButtonPress(1);
      InputReceived = true; // InputSleepCheck
      HapticFeebackDue = 1;
      START_STOP_FLAG = true;
      vTaskDelay(250 / portTICK_PERIOD_MS);
      break;
    case LEFT_BUTTON_BIT:
      InputReceived = true; // InputSleepCheck
      wheelButtonPress(5);
      HapticFeebackDue = 1;
      PREVIOUS_SONG_FLAG = true;
      vTaskDelay(250 / portTICK_PERIOD_MS);
      break;
    case RIGHT_BUTTON_BIT:
      InputReceived = true; // InputSleepCheck
      wheelButtonPress(4);
      HapticFeebackDue = 1;
      NEXT_SONG_FLAG = true;
      vTaskDelay(250 / portTICK_PERIOD_MS);
      break;
    case UP_BUTTON_BIT:
      InputReceived = true; // InputSleepCheck
      wheelButtonPress(2);
      HapticFeebackDue = 1;
      GO_BACK_FLAG = true;
      vTaskDelay(250 / portTICK_PERIOD_MS);
      break;
    case DOWN_BUTTON_BIT:
      InputReceived = true; // InputSleepCheck
      wheelButtonPress(3);
      HapticFeebackDue = 1;
      PLAY_PAUSE_FLAG = true;
      vTaskDelay(250 / portTICK_PERIOD_MS);
      break;
    }
  }
}

ICACHE_RAM_ATTR void wheelScroll(int Inc) {
  // Very simple and dirty smoothing function as I seem to be getting random
  // reverse events on scrolling
  ClickWheelScrollPrev[5] = ClickWheelScrollPrev[4];
  ClickWheelScrollPrev[4] = ClickWheelScrollPrev[3];
  ClickWheelScrollPrev[3] = ClickWheelScrollPrev[2];
  ClickWheelScrollPrev[2] = ClickWheelScrollPrev[1];
  ClickWheelScrollPrev[1] = ClickWheelScrollPrev[0];
  ClickWheelScrollPrev[0] = Inc;

  int NumMirrorResutsinhistory = 0;

  for (int i = 0; i <= 5;
       i++) { // check scroll history and count number of times the current
              // direction has been recorded
    if (ClickWheelScrollPrev[i] == Inc) {
      NumMirrorResutsinhistory++;
    }
  }

  // ignore the current wheel event if not simalar to recent
  if (NumMirrorResutsinhistory < ClickWheelNoiseFilterAmt) {
    return;
  }

  WheelSensitivity = 0;
  Serial.println(Inc);
  HapticFeebackDue = 1;
}

void wheelButtonPress(int WheelButton) {
  Serial.print("Button press - ");
  Serial.println(WheelButton);
  HapticFeebackDue = 1;
}

void loop() {
  // Execution should never get here
}

void startStopSongName(std::string songTitle) {
  Serial.print("Start song by name");
  musicPlayer.startPlayingFile(appendRootPath(songTitle.c_str()));
  currentMode = PLAYING;
  MainMenu.enable(MenuOption6);

  START_STOP_FLAG = false;
}

void startStopSong() {
  if (musicPlayer.stopped()) {
    Serial.print("Start ");
    Serial.print(currentTrack);
    Serial.print("=");
    Serial.println(trackListing[currentTrack]);
    std::string x = trackListing[currentTrack];
    musicPlayer.startPlayingFile(appendRootPath(x));
    currentMode = PLAYING;
    MainMenu.enable(MenuOption6);
  } else {
    Serial.println("Stopped.");
    musicPlayer.stopPlaying();
    currentMode = STOPPED;
    // in this block we will add possibility to skip to certain point
    // in
    // track
  }
  START_STOP_FLAG = false;
}
void playPauseSong() {
  if (!musicPlayer.stopped()) {
    if (!musicPlayer.paused()) {
      Serial.println("Paused");
      musicPlayer.pausePlaying(true);
      currentMode = PAUSED;
    } else {
      Serial.println("Resumed");
      musicPlayer.pausePlaying(false);
      currentMode = PLAYING;
    }
  }
  Serial.println(musicPlayer.decodeTime());
  PLAY_PAUSE_FLAG = false;
  MainMenu.drawHeader(false, 0); // TODO check if mainmenu or something else
}

void updatePlayerScreen() {
  MainMenu.drawTitleRow(trackListing[currentTrack], currentTrack + 1,
                        totalTracks);
}

void nextSong() {
  if (!musicPlayer.stopped()) {
    Serial.println("Stopping current playback.");
    musicPlayer.stopPlaying();
  }
  currentTrack = ++currentTrack < totalTracks ? currentTrack : 0;
  Serial.print("Next ");
  Serial.print(currentTrack);
  Serial.print("=");
  Serial.println(trackListing[currentTrack]);
  std::string x = trackListing[currentTrack];
  musicPlayer.startPlayingFile(appendRootPath(x));
  currentMode = PLAYING;
  NEXT_SONG_FLAG = false;

  if (NOW_PLAYING_SCREEN) {
    updatePlayerScreen();
  }
}

void previousSong() {
  if (currentTrack != 0) {
    --currentTrack;
    if (!musicPlayer.stopped()) {
      Serial.println("Stopping current playback.");
      musicPlayer.stopPlaying();
    }
    Serial.print("Next ");
    Serial.print(currentTrack);
    Serial.print("=");
    Serial.println(trackListing[currentTrack]);
    std::string x = trackListing[currentTrack];
    musicPlayer.startPlayingFile(appendRootPath(x));
    currentMode = PLAYING;

    if (NOW_PLAYING_SCREEN) {
      updatePlayerScreen();
    }
  }
  PREVIOUS_SONG_FLAG = false;
}

void updateVolumeSlider(bool volumeUp) {
  volumeSlider.drawSlider(20, 200, param);

  // Show bounding box (1 pixel outside slider working area)
  int16_t x, y;  // x and y can be negative
  uint16_t w, h; // Width and height

  // volumeSlider.setSliderPosition(100 - iVol);

  volumeSlider.getBoundingRect(&x, &y, &w, &h);
  display.drawRect(x, y, w, h, TFT_DARKGREY);

  if (volumeUp) {
    display.fillRect(x, y - 1, 100 - iVol, h - 1, TFT_BLUE);
  } else {
    display.fillRect(display.width() - x - iVol, y, 100 - iVol, h, TFT_WHITE);
  }

  // lastVolumeUpdate = millis();
}

void volumeUp() {
  if (iVol <= 0) {
    return;
  }

  if (iVol > 100) {
    iVol = 100;
  }
  // Set volume for left, right channels. lower numbers == louder
  // volume!
  if (iVol > -1) {
    iVol--;
    musicPlayer.setVolume(iVol, iVol);
    if (NOW_PLAYING_SCREEN) {
      updateVolumeSlider(true);
    }
  }
  SCROLL_UP_FLAG = false;
}

void volumeDown() {
  if (iVol >= 100) { // 255
    return;
  }
  // Set volume for left, right channels. lower numbers == louder
  // volume!
  if (iVol <= 100) {
    iVol++;
    if (iVol > 100) {
      iVol = 256;
    }

    musicPlayer.setVolume(iVol, iVol);

    if (NOW_PLAYING_SCREEN) {
      updateVolumeSlider(false);
    }
  }

  SCROLL_DOWN_FLAG = false;
}

void musicPlayerTask(void *pvParameters) {

  (void)pvParameters;

  // Loop forever
  while (1) {
    // Auto play next track if feature enabled
    if (AUTO_PLAY_NEXT) {
      if (currentMode == PLAYING && musicPlayer.stopped()) {
        if (SHUFFLE_MODE) {
          // nextRandomSong();
          nextSong();
        } else {
          nextSong();
        }
      }
    }
    if (PLAY_PAUSE_FLAG) {
      playPauseSong();
    }
    if (NEXT_SONG_FLAG) {
      nextSong();
    }
    if (PREVIOUS_SONG_FLAG) {
      previousSong();
    }
    if (VOLUME_UP_FLAG && NOW_PLAYING_SCREEN) {
      volumeUp();
    }
    if (VOLUME_DOWN_FLAG && NOW_PLAYING_SCREEN) {
      volumeDown();
    }
  }
}

void processMusicPlayerScreen(bool isPlaying, std::string songTitle) {

  NOW_PLAYING_SCREEN = true;
  display.fillScreen(MENU_BACKGROUND);
  MainMenu.setTitleText("Now Playing", " ");

  Serial.println(songTitle.c_str());

  if (!isPlaying) {
    startStopSong();
  }

  if (!songTitle.empty()) {
    Serial.println(songTitle.c_str());

    startStopSongName(songTitle);
  }

  MainMenu.drawHeader(false, 0);

  updatePlayerScreen();

  while (1) {

    if (SCROLL_UP_FLAG && NOW_PLAYING_SCREEN) {
      volumeUp();
      SCROLL_UP_FLAG = false;
    }
    if (SCROLL_DOWN_FLAG && NOW_PLAYING_SCREEN) {
      volumeDown();
      SCROLL_DOWN_FLAG = false;
    }

    if (GO_BACK_FLAG) {
      GO_BACK_FLAG = false;
      NOW_PLAYING_SCREEN = false;
      break;
    }

    // // TODO
    // if ((millis() - lastVolumeUpdate) / CLOCKS_PER_SEC >= 2) {
    //   display.fillRect(5, 190, 320, 50, TFT_BLACK);
    // }
  }
  MainMenu.setTitleText("iPod", "");
}
void processMusicList() {
  int musicListOption = 1;

  std::vector<std::string> listedSongs(cashedSongs);

  for (std::string song : listedSongs) {
    MusicList.addNI(song.c_str());
  }

  // blank out the screen
  display.fillScreen(MENU_BACKGROUND);

  // draw the main menu
  MusicList.draw();

  // Loop forever
  while (1) {

    // run the processing loop until user move selector to title bar (which
    // becomes exit, i.e. 0 return val) and selectes it note menu code can
    // return
    // - 1 for errors so run unitl non zero
    while (musicListOption != 0) {
      if (SCROLL_UP_FLAG && !NOW_PLAYING_SCREEN) {
        MusicList.MoveDown();
        SCROLL_UP_FLAG = false;
      }
      if (SCROLL_DOWN_FLAG && !NOW_PLAYING_SCREEN) {
        MusicList.MoveUp();
        SCROLL_DOWN_FLAG = false;
      }
      if (START_STOP_FLAG && !NOW_PLAYING_SCREEN) {
        START_STOP_FLAG = false;

        // get the row the selector is on
        musicListOption = MusicList.selectRow();

        currentTrack = musicListOption - 1;

        processMusicPlayerScreen(false, trackListing[musicListOption - 1]);

        // item 3 was the Option menu
        // processSettingsMenu();
        // when done processing that menu, return here
        // clear display and redraw this main menu
        display.fillScreen(MENU_BACKGROUND);
        MusicMenu.draw();
      }
      if (GO_BACK_FLAG) {
        musicListOption = 0;
        std::vector<std::string>().swap(listedSongs);
        MusicList.clear();
        break;
        // TODO
      }
    }

    if (musicListOption == 0) {
      MusicMenuOption = 4;
      musicListOption = 1;
      GO_BACK_FLAG = false;
      break;
      // TODO
    }
  }
}
void processMusicsMenu() {

  MusicMenuOption = 4;

  // blank out the screen
  display.fillScreen(MENU_BACKGROUND);

  // draw the main menu
  MusicMenu.draw();

  // Loop forever
  while (1) {

    // run the processing loop until user move selector to title bar (which
    // becomes exit, i.e. 0 return val) and selectes it note menu code can
    // return
    // - 1 for errors so run unitl non zero
    while (MusicMenuOption != 0) {
      if (SCROLL_UP_FLAG && !NOW_PLAYING_SCREEN) {
        MusicMenu.MoveDown();
        SCROLL_UP_FLAG = false;
      }
      if (SCROLL_DOWN_FLAG && !NOW_PLAYING_SCREEN) {
        MusicMenu.MoveUp();
        SCROLL_DOWN_FLAG = false;
      }
      if (START_STOP_FLAG && !NOW_PLAYING_SCREEN) {
        START_STOP_FLAG = false;

        // get the row the selector is on
        MusicMenuOption = MusicMenu.selectRow();

        // here is where you process accordingly
        // remember on pressing button on title bar 0 is returned and will
        // exit the loop

        if (MusicMenuOption == MenuOption4) {
          // item 3 was the Option menu
          processMusicList();
          // when done processing that menu, return here
          // clear display and redraw this main menu
          display.fillScreen(MENU_BACKGROUND);
          MusicMenu.draw();
        }
      }
      if (GO_BACK_FLAG) {
        MusicMenuOption = 0;
        break;
        // TODO
      }
    }

    if (MusicMenuOption == 0) {
      MainMenuOption = 4;
      GO_BACK_FLAG = false;
      break;
      // TODO
    }
  }
}

void processSettingsMenu() {

  // the entire menu processing are basically 3 calls
  // YourMenu.MoveUp();
  // YourMenu.MoveDown();
  // EditMenuOption = YourMenu.selectRow();

  // set an inital flag that will be used to store what menu item the user
  // exited on
  int EditMenuOption = 1;

  // blank out the screen
  display.fillScreen(MENU_BACKGROUND);

  // draw the main menu
  SettingsMenu.draw();

  // Loop forever
  while (1) {

    // run the processing loop until user move selector to title bar (which
    // becomes exit, i.e. 0 return val) and selectes it note menu code can
    // return
    // - 1 for errors so run unitl non zero
    while (EditMenuOption != 0) {
      if (SCROLL_UP_FLAG && !NOW_PLAYING_SCREEN) {
        SettingsMenu.MoveDown();
        SCROLL_UP_FLAG = false;
      }
      if (SCROLL_DOWN_FLAG && !NOW_PLAYING_SCREEN) {
        SettingsMenu.MoveUp();
        SCROLL_DOWN_FLAG = false;
      }
      if (GO_BACK_FLAG) {
        EditMenuOption = 0;
        break;
        // TODO
      }
    }

    if (EditMenuOption == 0) {
      MainMenuOption = 1;
      GO_BACK_FLAG = false;
      break;
      // TODO
    }
  }

  // user must have pressed the encorder select button while on the title
  // bar (which returns 0) hence exiting the loop now you can process /
  // store / display the menu selections remember this is from the EditMenu
  // and has associated value property with each menu item
  Serial.println("Option Menu Selections ");
  Serial.println("______________________________");
  Serial.print("Color Adj ");
  Serial.println(SettingsMenu.value[OptionOption1]);
  Serial.print("Temp2 Adj ");
  Serial.println(SettingsMenu.value[OptionOption2]);
  Serial.print("Readout ");
  Serial.println(ReadoutItems[(int)SettingsMenu.value[OptionOption3]]);
  Serial.print("Tune ");
  Serial.println(TuneItems[(int)SettingsMenu.value[OptionOption4]]);
  Serial.print("Alarm ");
  Serial.println(OffOnItems[(int)SettingsMenu.value[OptionOption5]]);
  Serial.print("Precision ");
  Serial.println(PrecisionItems[(int)SettingsMenu.value[OptionOption6]]);

  // an example of how to set other menu values based on selection here
  // remember all menu values passed in or returned are floats
  // so recast to int if you need to
  // AllowColorMenu = (int)SettingsMenu.value[OptionOption1];

  // if (AllowColorMenu == 0) {
  //   MainMenu.disable(MenuOption2);
  // } else {
  //   MainMenu.enable(MenuOption2);
  // }
}
